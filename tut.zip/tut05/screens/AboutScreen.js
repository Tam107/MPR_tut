import React, { useContext } from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import { MyContext } from '../App'; // Import context from App.js

export default function AboutScreen({ navigation }) {
    const { profile } = useContext(MyContext);

    return (
        <View style={styles.container}>
            <Text style={styles.text}>About {profile.name}, Age: {profile.age}</Text>
            <Button title="Go Back" onPress={() => navigation.goBack()} />
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, alignItems: 'center', justifyContent: 'center' },
    text: { fontSize: 20, fontWeight: 'bold' }
});
