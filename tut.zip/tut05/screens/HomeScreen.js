import React, { useContext, useState } from 'react';
import {View, Text, Button, TextInput, StyleSheet, TouchableOpacity} from 'react-native';
import { MyContext } from '../App'; // Import context from App.js

export default function HomeScreen({ navigation }) {
    const { profile, setProfile } = useContext(MyContext);
    const [newName, setNewName] = useState(profile.name);

    const handleDecreaseAge = () => {
        if (profile.age > 0) { // Check to ensure age doesn't go negative
            setProfile({ ...profile, age: profile.age - 1 });
        } else {
            alert("Age cannot be negative!"); // Optionally show an alert or toast
        }
    };

    return (
        <View style={styles.container}>
            <Text style={styles.text}>Current Name: {profile.name}</Text>
            <Text style={styles.text}>Current Age: {profile.age}</Text>

            {/* Input to Change Name */}
            <TextInput
                style={styles.input}
                value={newName}
                onChangeText={(text) => setNewName(text)}
                placeholder="Enter new name"
            />

            {/* Button to Update Name */}

            <TouchableOpacity style={styles.button} onPress={() => setProfile({ ...profile, name: newName })}>
                <Text>Change Name </Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.button} onPress={() => setProfile({ ...profile, age: profile.age + 1 })}>
                <Text>Increase Age </Text>
            </TouchableOpacity>

            <Button title="Decrease Age" onPress={handleDecreaseAge} />

            {/* Navigate to About Page */}
            <Button title="Go to About" onPress={() => navigation.navigate('About')} />
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, alignItems: 'center', justifyContent: 'center' },
    text: { fontSize: 20, fontWeight: 'bold', marginBottom: 10 },
    input: { borderWidth: 1, width: 200, padding: 10, marginBottom: 10 },
    button: {
        backgroundColor: 'white',
        padding: 10,
        borderRadius: 5,
        marginBottom: 10,
        width: '35%',
        alignItems: 'center',
        borderColor: 'black',
        borderWidth: 1
    },
});
