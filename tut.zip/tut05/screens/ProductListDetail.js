import {StyleSheet, Text, View} from 'react-native'
import React from 'react'

const ProductListDetail = () => {
    return (
        <View>
            <Text>ProductListDetail</Text>
        </View>
    )
}
export default ProductListDetail
const styles = StyleSheet.create({})
