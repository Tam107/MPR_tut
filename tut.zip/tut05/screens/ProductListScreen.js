import {FlatList, KeyboardAvoidingView, ScrollView, StyleSheet, Text, TouchableOpacity, View} from 'react-native'
import React, {useState} from 'react'
import ProductItem from "../components/ProductItem";
import AddProductForm from "../components/AddProductForm";

const ProductListScreen = ({navigation, route}) => {
    const [products, setProducts] = useState([
        {id: '1', name: 'Laptop', price: 1000, description: 'Laptop'},
        {id: '2', name: 'Laptop', price: 1000, description: 'Laptop'},
    ])
    const [showAddForm, setShowAddForm] = useState(false)

    const handleAddProduct = (product) => {
        const newProducts = {
            ...product,
            id: String(product.length + 1)
        };
        setProducts([...products, newProducts]);
    }

    const handleProductPress = (product) => {
        navigation.navigate('ProductDetail', {product: product});
    }

    return (
        <KeyboardAvoidingView className={"flex-1"}>
            <View className={"flex-1 bg-white p-4"}>
                <View className={"flex-row justify-between items-center mb-4"}>
                    <Text className={"text-xl font-bold"}></Text>
                    <TouchableOpacity onPress={() => setShowAddForm(!showAddForm)}
                                      className={"bg-blue-400 py-2 px-4 rounded-md shadow-sm"}>
                        <Text className={"text-white font-medium"}>
                            {showAddForm ? 'Hide Form' : 'Add Product'}
                        </Text>
                    </TouchableOpacity>
                </View>

                {/*    Add Product Form*/}
                {showAddForm && (
                    <AddProductForm onAddProduct={handleAddProduct} onCancel={() => setShowAddForm(false)}/>)}

                {/*    Product List*/}
                <FlatList data={products} keyExtractor={(item) => item.id} renderItem={({item}) => (
                    <ProductItem product={item} onPress={() => handleProductPress(item)}/>
                )}>

                </FlatList>

            </View>
        </KeyboardAvoidingView>
    )
}
export default ProductListScreen
