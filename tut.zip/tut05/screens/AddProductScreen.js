import {StyleSheet, Text, View} from 'react-native'
import React from 'react'

const AddProductScreen = () => {
    return (
        <View>
            <Text>AddProductScreen</Text>
        </View>
    )
}
export default AddProductScreen
const styles = StyleSheet.create({})
