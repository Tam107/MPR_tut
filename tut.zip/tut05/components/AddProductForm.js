import {StyleSheet, Text, TextInput, TouchableOpacity, View} from 'react-native'
import React, {useState} from 'react'

const AddProductForm = () => {
    const [productName, setProductName] = useState('');
    const [productPrice, setProductPrice] = useState('');
    const [productDescription, setProductDescription] = useState('');
    const [error, setError] = useState({});

    function handleSubmit() {

    }

    return (
        <View className={"bg-white p-4 rounded-md shadow-md mb-4 border border-gray-100"}>
            <Text className={"text-lg font-bold mb-4"}>Add New Product</Text>

            {/*    Input for adding product*/}
            <View className={"mb-4"}>
                {/*<Text className={"text-orange-300 text-xs font-bold mb-1"}>Product Name</Text>*/}
                <TextInput className={`border ${error.name ? 'border-red-400' : 'border-gray-200'} rounded p-2`
                } value={productName}
                           onChange={e => setProductName(e.target.value)} placeholder={"Enter Product Name"}/>
                {error.name && <Text className={"text-red-300 text-xs mt-1"}>{error.name}</Text>}
            </View>

            <View className={"mb-4"}>
                {/*<Text className={"text-orange-300 text-xs font-bold mb-1"}>Product Price</Text>*/}
                <TextInput className={`border ${error.name ? 'border-red-400': 'border-gray-200'} rounded p-2`}
                           value={productPrice}
                           onChangeText={e => setProductPrice(e.target.value)}
                            placeholder={"Enter Product Price"}/>
            </View>
            <View className={"mb-1"}>
                {/*<Text className={"text-orange-300 text-xs font-bold mb-1"}>Product Price</Text>*/}
                <TextInput className={`border ${error.name ? 'border-red-400': 'border-gray-200'} rounded p-2`}
                           value={productDescription}
                           onChangeText={e => setProductDescription(e.target.value)}
                           placeholder={"Enter Product Description"}
                           multiline
                           numberOfLines={3}
                           textAlignVertical="top"
                />
            </View>

            <View className={"flex justify-center items-center mt-2"}>
                <TouchableOpacity onPress={handleSubmit}
                                  className="bg-blue-500 py-2 px-4 rounded-md"
                >
                    <Text className={"font-bold text-white"}>Submit</Text>
                </TouchableOpacity>
            </View>
        </View>
    )
}
export default AddProductForm
const styles = StyleSheet.create({})
