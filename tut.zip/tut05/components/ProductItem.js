import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';

const ProductItem = ({ product, onPress }) => {
    return (
        <TouchableOpacity
            onPress={onPress}
            className="bg-white mb-3 p-4 rounded-lg shadow-sm border border-gray-200"
        >
            <View className="flex-row justify-between items-center">
                <View className="flex-1">
                    <Text className="text-lg font-medium">{product.name}</Text>
                    <Text className="text-gray-600 text-sm mt-1">{product.description}</Text>
                </View>

                <View className="bg-blue-100 px-3 py-2 rounded-md">
                    <Text className="text-blue-800 font-bold">${product.price.toFixed(2)}</Text>
                </View>
            </View>
        </TouchableOpacity>
    );
};

export default ProductItem;
