import React, { createContext, useContext, useState } from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

const Test = () => {
    const [profile, setProfile] = useState({
        name: "tam",
        age: 5
    });

    return (
        <MyContext.Provider value={{ profile, setProfile }}>
            <NavigationContainer>
                <Stack.Navigator>
                    <Stack.Screen name="Home" component={HomeScreen} />
                    <Stack.Screen name="About" component={AboutScreen} />
                </Stack.Navigator>
            </NavigationContainer>
        </MyContext.Provider>

    )
}
export default Test
const styles = StyleSheet.create({})
