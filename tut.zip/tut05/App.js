import React, { createContext, useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
// import HomeScreen from "./screens/HomeScreen";
// import AboutScreen from "./screens/AboutScreen";
import ProductListScreen from "./screens/ProductListScreen";
import ProductListDetail from "./screens/ProductListDetail";
import AddProductScreen from "./screens/AddProductScreen";

// 🟢 Context must be defined outside the component
export const MyContext = createContext(null);

// 🟡 Stack Navigator
const Stack = createNativeStackNavigator();

export default function App() {
    const [profile, setProfile] = useState({
        name: "Tam",
        age: 5
    });

    return (
        <MyContext.Provider value={{ profile, setProfile }}>
            <NavigationContainer>
                <Stack.Navigator>
                    {/*<Stack.Screen name="Home" component={HomeScreen} />*/}
                    {/*<Stack.Screen name="About" component={AboutScreen} />*/}
                    <Stack.Screen name="ProductList" component={ProductListScreen} options={{title: 'Products List Screen'}} />
                    <Stack.Screen name="ProductDetail" component={ProductListDetail} />
                    <Stack.Screen name="AddProduct" component={AddProductScreen} />
                </Stack.Navigator>
            </NavigationContainer>
        </MyContext.Provider>
    );
}


// import React, { useState } from 'react';
// import {
//     View,
//     Text,
//     Button,
//     FlatList,
//     TextInput,
//     StyleSheet,
//     TouchableOpacity
// } from 'react-native';
// import { NavigationContainer } from '@react-navigation/native';
// import { createNativeStackNavigator } from '@react-navigation/native-stack';
//
// const Stack = createNativeStackNavigator();
//
// const ProductListScreen = ({ navigation }) => {
//     const [products, setProducts] = useState([
//         { id: '1', name: 'Laptop', price: 1000, description: 'High-performance laptop' },
//         { id: '2', name: 'Smartphone', price: 500, description: 'Latest model smartphone' }
//     ]);
//
//     const [newProduct, setNewProduct] = useState({
//         name: '',
//         price: '',
//         description: ''
//     });
//
//     const addProduct = () => {
//         if (newProduct.name && newProduct.price) {
//             const product = {
//                 id: String(products.length + 1),
//                 ...newProduct,
//                 price: parseFloat(newProduct.price)
//             };
//             setProducts([...products, product]);
//             setNewProduct({ name: '', price: '', description: '' });
//         }
//     };
//
//     return (
//         <View style={styles.container}>
//             <FlatList
//                 data={products}
//                 keyExtractor={(item) => item.id}
//                 renderItem={({ item }) => (
//                     <TouchableOpacity
//                         style={styles.productItem}
//                         onPress={() => navigation.navigate('ProductDetail', { product: item })}
//                     >
//                         <Text>{item.name}</Text>
//                         <Text>${item.price}</Text>
//                     </TouchableOpacity>
//                 )}
//             />
//
//             <View style={styles.form}>
//                 <TextInput
//                     style={styles.input}
//                     placeholder="Product Name"
//                     value={newProduct.name}
//                     onChangeText={(text) => setNewProduct({...newProduct, name: text})}
//                 />
//                 <TextInput
//                     style={styles.input}
//                     placeholder="Price"
//                     keyboardType="numeric"
//                     value={newProduct.price}
//                     onChangeText={(text) => setNewProduct({...newProduct, price: text})}
//                 />
//                 <TextInput
//                     style={styles.input}
//                     placeholder="Description"
//                     value={newProduct.description}
//                     onChangeText={(text) => setNewProduct({...newProduct, description: text})}
//                 />
//                 <Button title="Add Product" onPress={addProduct} />
//             </View>
//         </View>
//     );
// };
//
// const ProductDetailScreen = ({ route }) => {
//     const { product } = route.params;
//
//     return (
//         <View style={styles.container}>
//             <Text style={styles.detailTitle}>{product.name}</Text>
//             <Text>Price: ${product.price}</Text>
//             <Text>Description: {product.description}</Text>
//         </View>
//     );
// };
//
// export default function App() {
//     return (
//         <NavigationContainer>
//             <Stack.Navigator>
//                 <Stack.Screen
//                     name="ProductList"
//                     component={ProductListScreen}
//                     options={{ title: 'Product List' }}
//                 />
//                 <Stack.Screen
//                     name="ProductDetail"
//                     component={ProductDetailScreen}
//                     options={{ title: 'Product Details' }}
//                 />
//             </Stack.Navigator>
//         </NavigationContainer>
//     );
// }
//
// const styles = StyleSheet.create({
//     container: {
//         flex: 1,
//         padding: 20,
//     },
//     productItem: {
//         flexDirection: 'row',
//         justifyContent: 'space-between',
//         padding: 15,
//         borderBottomWidth: 1,
//         borderBottomColor: '#ccc'
//     },
//     form: {
//         marginTop: 20,
//     },
//     input: {
//         borderWidth: 1,
//         borderColor: '#ccc',
//         padding: 10,
//         marginBottom: 10,
//     },
//     detailTitle: {
//         fontSize: 24,
//         fontWeight: 'bold',
//         marginBottom: 20,
//     }
// });